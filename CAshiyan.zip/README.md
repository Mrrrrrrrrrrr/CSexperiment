# CSexperiment
This is the repository of Computer System experiment.
Put on questions in this file and make sure all of them be solved at the end of experiment.

QMR：
2022.11.28
初始化MyCPU，将样例上传。

2022.11.28-2022.11.29
完成除LOAD数据相关的数据相关。

2022.11.30
完成指令SUBU、JR、JAL的添加。目前到达PC值bfc05114。

LPD：
2022.12.02
完成指令ADDU、BNE、SLL、OR的添加。目前到达PC值bfc00d58。

QMR：
2022.12.04-2022.12.05
完成XOR与所有算数运算指令的添加，完成LW和SW的框架。

2022.12.05
完成简单的LW和SW访存指令，暂未设计数据相关处理，目前通过一号点，到达PC值bfc00d5c。
